const mongoose = require("mongoose")

const Funcionario = mongoose.model('Funcionario',{
    name: String,
    salario: String,
    cpf: String
})

module.exports = Funcionario