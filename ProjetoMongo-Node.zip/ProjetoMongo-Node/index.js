// Express
const express = require("express")
const app = express()
const cors = require('cors');

// MONGODB
const connectDB = require("./database/mongodbs")
connectDB();
const Funcionario = require("./models/funcionarios");

//app use
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use(cors());

// Crud
app.get('/', (req, res) => {
    res.send("Hi")
})

app.post('/funcionario', async (req, res) => {
    const { name, salario, cpf } = req.body;

    // Verifica se todos os campos obrigatórios estão presentes
    if (!name) {
        return res.status(400).json({ error: 'Nome é obrigatorio!' });
    }

    const funcionario = {
        name,
        salario,
        cpf
    }

    try {
        await Funcionario.create(funcionario)
        res.status(201).json({ message: 'Funcionario criado com sucesso!' })
        console.log(name, salario, cpf)
    } catch (error) {
        res.status(500).json({ error: error.message })
    }
})

app.get('/findfuncionarios', async (req, res) => {
    try {
        const funcionarios = await Funcionario.find();
        res.status(200).json(funcionarios);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});
app.put('/funcionarioupdate/:id', async (req, res) => {
    const { id } = req.params;
    const { name, salario, cpf } = req.body;

    // Verifica se todos os campos obrigatórios estão presentes
    if (!name) {
        return res.status(400).json({ error: 'Nome é obrigatório!' });
    }

    try {
        const funcionario = await Funcionario.findByIdAndUpdate(
            id,
            { name, salario, cpf },
            { new: true }
        );
        res.status(200).json(funcionario);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.delete('/funcionariodelete/:id', async (req, res) => {
    const { id } = req.params;

    try {
        await Funcionario.findByIdAndDelete(id);
        res.status(200).json({ message: 'Funcionario excluído com sucesso!' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});


// Porta
const port = 3000
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`)
})
