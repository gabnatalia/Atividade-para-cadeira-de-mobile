
const mongoose = require('mongoose');

const connectDB = async () => {
    try {
        const username = 'digite seu username';
        const password = 'digite sua senha';

        await mongoose.connect(`mongodb+srv://${username}:${encodeURIComponent(password)}@primeiraconexaomongodb.opufdcz.mongodb.net/`, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        console.log('Conexão com o banco de dados estabelecida com sucesso!');
        // Faça aqui as operações que deseja realizar após a autenticação bem-sucedida
    } catch (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
    }
};

module.exports = connectDB;
