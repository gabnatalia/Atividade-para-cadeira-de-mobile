axios.get('http://localhost:3000/findfuncionarios')
    .then(function (response) {
        const employees = response.data;
        const tableBody = document.querySelector('#employee-table tbody');

        employees.forEach(function (employee) {
            const row = document.createElement('tr');

            const nameCell = document.createElement('td');
            nameCell.textContent = employee.name;
            row.appendChild(nameCell);

            const salaryCell = document.createElement('td');
            salaryCell.textContent = employee.salario;
            row.appendChild(salaryCell);

            const cpfCell = document.createElement('td');
            cpfCell.textContent = employee.cpf;
            row.appendChild(cpfCell);

            tableBody.appendChild(row);
        });
    })
    .catch(function (error) {
        console.error(error);
    });
