
self.addEventListener('install', event => {
    self.skipWaiting();

    event.waitUntil(
        caches.open(cacheName).then(cache => cache.addAll([
            './index.html',
            './apiget.js',
            '/assets/icons/carteira-de-identidade 512.png',
            '/assets/icons/carteira-de-identidade 256.png',
            '/assets/icons/carteira-de-identidade 192.png',
            '/assets/icons/carteira-de-identidade 180.png',
            '/assets/icons/carteira-de-identidade 167.png',
            '/assets/icons/carteira-de-identidade 152.png',
            '/assets/icons/carteira-de-identidade 144.png',
            '/assets/icons/carteira-de-identidade 128.png'
            
            
        ]))
    );
});

self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request).then(response => {
            return response || fetch(event.request);
        })
    );
});
